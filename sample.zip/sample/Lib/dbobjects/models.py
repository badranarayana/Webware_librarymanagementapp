from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy.orm import sessionmaker
from sqlalchemy import Column, ForeignKey, Integer, String, DateTime


Base = declarative_base()


class Subscriber(Base):
    __tablename__ = 'subscriber'
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(30), nullable=False)
    mobile_no = Column(String(12), nullable=False)
    email = Column(String(30), nullable=False)


class Book(Base):
    __tablename__ = "book"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(50), nullable=False)
    author_name = Column(String(50), nullable=False)
    quantity = Column(Integer, nullable=0, default=0)



class Subscriptions(Base):
    __tablename__ = 'subscriptions'
    id = Column(Integer, primary_key=True, autoincrement=True)
    book_id = Column(Integer, ForeignKey('book.id'), nullable=False)
    subsriber_id = Column(Integer, ForeignKey('subscriber.id'), nullable=False)
    issue_from = Column(DateTime, nullable=False)
    expected_return = Column(DateTime, nullable=False)
    status = Column(String(20), nullable=False, default="Issued")

    subscriber = relationship(Subscriber)
    book = relationship(Book)
def getSession():
    engine = create_engine('sqlite:///library.db', echo=True)
    Session = sessionmaker()
    Session.configure(bind=engine)
    session_object = Session()
    return session_object

def insertRecord(models_object):
    db_session = getSession()
    db_session.add(models_object)
    db_session.commit()
    return None

def updateRecord(models_object, fileds):
    pass

def deleteRecord(models_object):
    pass


def create_tables():
    engine = create_engine('sqlite:///library.db', echo=False)
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)

if __name__ == '__main__':

    # engine = create_engine('sqlite:///library.db', echo=False)
    #
    # #Base.metadata.drop_all(engine)
    # Base.metadata.create_all(engine)
    #
    # Session = sessionmaker()
    # Session.configure(bind=engine)
    #
    # s = Session()
    # # insert subscriber
    #s1 = Subscriber(id =2, name ="Badra", mobile_no = "9010326382", email = "badra@gmail.com")
    # s.flush()
    # book = Book(id=2, name="Test book", author_name="Test author", quantity=4)
    # s.add(s1)
    # s.add(book)
    # s.commit()
    # sub_data = s.query(Subscriber)
    # for data in sub_data:
    #     print data.name, data.email
    #
    # sub_data = s.query(Book)
    # for data in sub_data:
    #     print data.name, data.author_name
    db_session = getSession()
    create_tables()
    s1 = Subscriber(name="Bad", mobile_no="926382", email="badr1a@gmail.com")
    insertRecord(s1)
    sub_data = db_session.query(Subscriber)
    for data in sub_data:
        print data.name, data.email


