#!/usr/bin/env python
"""
Unit-testing for FunFormKit
"""

import sys

sys.path.append("../..")

try:
	from unittest import TestSuite, TestCase
	import unittest
except:
	from unittest_local_copy import TestSuite, TestCase
	import unittest_local_copy
	unittest = unittest_local_copy
from MiscUtils import NoDefault
from FunFormKit import Form, Field, Validator
try:
	from mx import DateTime
except ImportError:
	import DateTime
import string

############################################################
## Constants and globals

True, False = (1==1), (0==1)

############################################################
## Helper classes
## (environment simulators)
## Not really used yet -- figuring this portion out is the hard
## bit of it.

class FakeRequest:
	def __init__(self, sourceDict):
		self._dict = sourceDict
	def field(self, name, default=NoDefault):
		if default is NoDefault:
			return self._dict[name]
		else:
			return self._dict.get(name, default)
	def hasField(self, name):
		return self._dict.has_key(name)
	def fields(self):
		return self._dict

class FakeServlet(Form.FormServlet):
	def __init__(self, formDefinitions, defaultFormDefinition=None):
		for formDefinition in formDefinitions:
			setattr(self, formDefinition.renderMethodName(),
					lambda s=self, f=FormDefinition: s.render(f))
			for field in formDefinition.fields():
				if field.isSubmit():
					setattr(self, field.methodToInvoke(),
							lambda fields, s=self, f=formDefinition, b=field: s.respond(fields, f, b))
		Form.FormServlet.__init__(self, 'startFormServlet',
								  formDefinitions=formDefinitions,
								  defaultFormDefinition=defaultFormDefinition)
		

############################################################
## FunFormKit description

selectOptions = [{"selections": [(1, 1), (2, 2), (3, 3)]},
				 {"selections": [("a", "b"), (1, 2)]},
				 {"selections": [(1L, 5), (2.0, 6)]},
				 {"selections": [(Field.SelectField, "X")]},
				 {"selections": [(1, 1), (2, 2)],
				  "nullInput": "whatever"},
				 {"selections": [(1, 2)],
				  "size": 10},
				 {"dynamic": True,
				  "options": {"selections": [(1, 1)]}},
				 {"dynamic": True,
				  "options": {"selections": [("a", "b")]}}]

def filterOut(optionName, options):
	return filter(lambda op, on=optionName: not op.has_key(on), options)

fields = [
	[Field.SubmitButton, [{"options": {"emptyHidden": True}},
						  {"methodToInvoke": "nothing",
						   "options": {"emptyHidden": True}},
						  {"confirm": "a simple test",
						   "options": {"emptyHidden": True}},
						  {"confirm": "quotes \" and \'",
						   "options": {"emptyHidden": True}},
						  {"suppressValidation": True,
						   "options": {"emptyHidden": True}},
						  ]],
	[Field.HiddenField, [{}]],
	[Field.TextField, [{},
					   {"size": 10},
					   {"maxLength": 5},
					   {"size": 20, "maxLength": 30}
					   ]],
	[Field.TextareaField, [{},
						   {"rows": 10, "cols": 20},
						   {"wrap": "hard"},
						   ]],
	[Field.PasswordField, [{},
						   {"size": 100},
						   {"maxLength": 1},
						   {"size": 100, "maxLength": 50},
						   ]],
	[Field.SelectField, selectOptions],
	[Field.OrderingField, filterOut('size', filterOut('nullInput', selectOptions))],
	[Field.RadioField, filterOut('size', filterOut('nullInput', selectOptions))],
	[Field.MultiSelectField, filterOut('nullInput', selectOptions)],
	[Field.MultiCheckboxField, filterOut('nullInput', filterOut('size', selectOptions))],
	[Field.CheckboxField, [{}]],
	[Field.DateField, [{"options": {"canHide": False}},
					   {"earliestDate": DateTime.now(),
						"options": {"canHide": False}},
					   {"latestDate": DateTime.now(),
						"options": {"canHide": False}},
					   {"yearTextInput": False,
						"earliestDate": DateTime.now(),
						"latestDate": DateTime.now() + 365*10,
						"options": {"canHide": False}},
					   {"yearTextInput": True,
						"options": {"canHide": False}},
					   {"allowEmpty": True,
						"options": {"emptyHidden": True}},
					   {"earliestDate": DateTime.now(),
						"latestDate": DateTime.DateTime(2100, 10, 5),
						"options": {"canHide": False}},
					   ]],
	[Field.StaticText, [{"text": "hello world",
						 "options": {"emptyHidden": True}}]],
	[Field.FileField, [{"options": {"canHide": False}},
					   {"size": 10,
						"options": {"canHide": False}},
					   {"returnString": True},
					   {"mimeTypes": ["text/html", "text/plain"],
						"options": {"canHide": False}},
					   {"size": 5,
						"mimeTypes": ["application/octet-stream"],
						"returnString": True},
					   ]],
	]
	
	
############################################################
## Test cases


########################################
## Fields

class FieldTestCase(TestCase):
	def __init__(self, fieldClass, keywordArgs, id):
		self.fieldClass = fieldClass
		self.keywordArgs = keywordArgs
		self.id = id
		unittest.TestCase.__init__(self)
	def updateOptions(self):
		return None
	def shortDescription(self):
		return self.__class__.__name__ + " " + self.fieldClass.__name__ + " %i" % self.id
	def setUp(self):
		if self.updateOptions():
			self.keywordArgs["options"] = self.keywordArgs.get("options", {})
			self.keywordArgs["options"].update(self.updateOptions())
		self.field = apply(self.fieldClass, ('test',), self.keywordArgs)

class FieldRender(FieldTestCase):
	def runTest(self):
		assert self.field.html(), "empty rendering"
class FieldDescription(FieldTestCase):
	def runTest(self):
		assert self.field.description(), "No description"
		assert self.field.name(), "No name"
class FieldOptionThru(FieldTestCase):
	def updateOptions(self):
		return {"thru": "yes"}
	def runTest(self):
		assert self.field.option('thru') == "yes"
		assert self.field.option('test', {"test": "yes"}) == "yes"
		assert self.field.option('thru', {'thru': "no"}) == "no"
		assert self.field.option('nothing', default="yup") == "yup"
class FieldHidden(FieldTestCase):
	def updateOptions(self):
		return {"hide": True}
	def runTest(self):
		if self.field.option('canHide', default=True):
			value = self.field.html()
			assert type(value) is type("")
			if not self.field.option('emptyHidden', default=False):
				assert value != ''
		else:
			self.assertRaises(Form.FormError, self.field.html)
class FieldStatic(FieldHidden):
	def updateOptions(self):
		return {"static": True}

suites = {}
suiterizers = [FieldRender, FieldDescription, FieldOptionThru, FieldHidden,
			   FieldStatic]
for suiterize in suiterizers:
	suites[suiterize.__name__] = TestSuite()
for fieldClass, constructors in fields:
	id = 1
	for constructor in constructors:
		for suiterize in suiterizers:
			t = suiterize(fieldClass, constructor, id)
			suites[suiterize.__name__].addTest(t)
		id = id + 1

excersizeFields = TestSuite(suites.values())

########################################
## Validator

## A list of cases to test
## Each sublist has:
## validatorClass, __init__ args, __init__ keyword args,
## [ (input, output),...]
## .attemptConvert(input) should produce output.  If output
## is Validator.InvalidField, then .attemptConvert(input)
## should raise an InvalidField exception.
testValidatorCases = [
	[Validator.MaxLength, [10], {},
	 [("test", "test"),
	  ("longtestandstuff", Validator.InvalidField),
	  ]],
	]

class ValidatorTest(TestCase):
	def __init__(self, validatorClass, args, keywordArgs, input, output):
		self.validatorClass = validatorClass
		self.args = args
		self.keywordArgs = keywordArgs
		self.input = input
		self.output = output
		self.id = id
		TestCase.__init__(self)
	def setUp(self):
		self.validator = apply(self.validatorClass, self.args,
							   self.keywordArgs)
	def runTest(self):
		try:
			value = self.validator.attemptConvert(self.input)
			assert self.output is not Validator.InvalidField, "Should have raised InvalidField"
			assert self.output == value, "Unexpected result"
		except Validator.InvalidField:
			assert self.output is Validator.InvalidField, "Should not have raised InvalidField"
	def shortDescription(self):
		return "%s %s(%s) %s" % (self.__class__.__name__,
								 self.validatorClass.__name__,
								 string.join(args + map(lambda x: x[0] + "=" + repr(x[1]), self.keywordArgs.items()), ", "),
								 repr(self.input))


validatorSuite = TestSuite()
for case in testValidatorCases:
	validator = case[0]
	args = case[1]
	kwArgs = case[2]
	for input, output in case[3]:
		validatorSuite.addTest(ValidatorTest(validator, args, kwArgs,
											 input, output))


def allSuites():
	return TestSuite((excersizeFields, validatorSuite))

def runTests():
	runner = unittest.TextTestRunner(stream=sys.stdout)
	unittest.main(defaultTest="allSuites", testRunner=runner)

if __name__=="__main__":
	runTests()
	
