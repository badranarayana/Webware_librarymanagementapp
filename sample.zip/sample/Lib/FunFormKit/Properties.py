name = 'FunFormKit'

version = (0, 4, 1)

docs = [{'name': 'Quick Start Guide',
         'file': 'QuickStart.html'},
        {'name': 'User Guide',
         'file': 'UserGuide.html'},
        {'name': 'Tips',
         'file': 'Tips.html'},
        ]

status = 'beta'

requiredPyVersion = (2, 0, 0)

synopsis = """FormKit provides validation and HTML-generation for forms"""

WebKitConfig = {
    'examplePages': ['Register', 'EditUser',
                     'ComplexRegister', 'Login',
                     'AddressList'],
    }
