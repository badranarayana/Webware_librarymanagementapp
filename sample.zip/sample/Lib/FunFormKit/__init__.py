def InstallInWebKit(appserver):
    pass
