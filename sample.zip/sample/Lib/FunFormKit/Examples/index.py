from WebKit.Examples.ExamplePage import ExamplePage

class index(ExamplePage):
    pass
