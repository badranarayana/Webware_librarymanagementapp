from FunFormKit.Form import *
from FunFormKit.Field import *
from FunFormKit import Validator
from WebKit.Examples.ExamplePage import ExamplePage

formDef = FormDefinition(
    "Register",
    [TextField("firstName", maxLength=20, validators=[Validator.NotEmpty()]),
     TextField("middleInitial", description="MI",
               size=1, maxLength=1),
     TextField("lastName", maxLength=50, size=20, validators=[Validator.NotEmpty()]),
     TextField("email", size=20, validators=[Validator.NotEmpty(), Validator.Email()]),
     TextareaField("address", rows=4, cols=40),
     PasswordVerifyField("password", size=20, validators=[Validator.NotEmpty()]),
     SelectField("gender", selections=[("male", "Male"), ("female", "Female")], nullInput="Gender"),
     TextField("age", size=2, maxLength=2, validators=[Validator.AsInt()]),
     SubmitButton("submit", methodToInvoke="register"),
     ])

layout = [("firstName*", "middleInitial", "lastName*"),
          "email*",
          "address",
          ":password",
          ("gender", "age*"),
          "submit",
         ]

class Register(ExamplePage, FormServlet):
    
    def __init__(self):
        ExamplePage.__init__(self)
        FormServlet.__init__(self, formDef)

    def writeContent(self):
        # .processForm() is inherited from FormServlet
        formProcessed, data = self.processForm()
        if formProcessed:
            self.write('Thanks for signing up!')
        else:
            self.renderForm()

    def renderForm(self):
        renderableForm = self.renderableForm()
        self.write(renderableForm.htFormLayout(layout, spacing=2))


    def register(self, fields):
        # ... do something to register user in database here ...
        # fields is a dictionary, filled from the form, field
        # names as keys.
        self.session().setValue('userInfo', fields)
