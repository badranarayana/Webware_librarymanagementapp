"""
Example for FunFormKit.  See the Quick Start Guide for commentary.
"""

from WebKit.Examples.ExamplePage import ExamplePage
from FunFormKit.Form import FormServlet, FormDefinition
from FunFormKit import Field
from FunFormKit.Validator import ValidatorConverter, FormValidator, \
     InvalidField
from WebUtils.Funcs import htmlEncode
import random

## These are some arbitrary functions to make this interesting.
## In the real world these would probably involve accessing a
## database.

usernames = {
    "bob": 1,
    "alice": 2,
    "joe": 3,
    }

password = {
    1: "passbob",
    2: "passalice",
    3: "passjoe",
    }

def usernameExists(username):
    return usernames.has_key(username)
def usernameToUserID(username):
    return usernames.get(username, None)
def correctPassword(userID, attemptedPassword):
    return password[userID] == attemptedPassword

## The main code.
## For a description of this, look in the Quick Start Guide,
## which uses this as an example.

class UsernameToUserID(ValidatorConverter):
    def convert(self, username):
        userID = usernameToUserID(username)
        if userID is None:
            raise InvalidField, "That username does not exist"
        else:
            return userID

class ValidatePassword(FormValidator):
    
    def validate(self, fieldDict):
        print fieldDict
        if correctPassword(fieldDict["username"], fieldDict["password"]):
            return None
        else:
            return {"password": "Password is incorrect -- use %s" % password[fieldDict["username"]]}

formDef = FormDefinition('Login',
                         [Field.TextField('username', maxLength=10,
                                          validators=[UsernameToUserID()]),
                          Field.PasswordField('password', size=10, maxLength=20),
                          Field.SubmitButton('submit', description='Login'), 
                         ],
                         formValidators=[ValidatePassword()])


class Login(ExamplePage, FormServlet):

    def __init__(self):
        ## 'writeContent' is the method that is overidden.  That's what
        ## ExamplePage calls.  'writeForm' is the method that writes
        ## the form (not the one that handles the result).  We declared
        ## the method that handles the result when we created
        ## SubmitButton.
        FormServlet.__init__(self, [formDef])
        ExamplePage.__init__(self)

    def writeContent(self):
        submitted, data = self.processForm()
        if not submitted:
            rf = self.renderableForm()
            self.write(rf.htFormTable(bgcolor="#ddddff"))
        else:
            self.write("Welcome User <b>#%s</b>!" % data['username'])

