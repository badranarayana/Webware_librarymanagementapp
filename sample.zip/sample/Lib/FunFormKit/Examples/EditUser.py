from FunFormKit.Form import *
from WebKit.Examples.ExamplePage import ExamplePage
from Register import formDef, layout

class EditUser(ExamplePage, FormServlet):

    def __init__(self):
        ExamplePage.__init__(self)
        FormServlet.__init__(self, formDef)

    def writeContent(self):
        formProcessed, data = self.processForm()
        if formProcessed:
            self.write('You user information has been saved!')
        else:
            fields = self.session().value('userInfo', None)
            if not fields:
                self.write('You must Register first!')
            else:
                self.renderForm(fields)

    def renderForm(self, fields):
        # Normally the form definition will point to Register.
        # We set this special form option to change that:
        optionSet = {'form': {'handlerServletURL': 'EditUser'}}
        rf = self.renderableForm(defaults=fields, optionSet=optionSet)
        self.write(rf.htFormLayout(layout))

    def register(self, fields):
        self.session().setValue('userInfo', fields)
