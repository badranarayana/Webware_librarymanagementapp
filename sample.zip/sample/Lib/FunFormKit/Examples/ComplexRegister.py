"""
Example for FunFormKit mixin.  Slightly more complex registration
page.  The action doesn't do anything very useful, or even nice.  But
that's not really the point, is it?  Once the form is successfully
submitted it's not FFK's responsibility.
"""

from WebKit.Examples.ExamplePage import ExamplePage
from FunFormKit.Form import *
from FunFormKit.Field import *
from FunFormKit import Validator
from WebUtils.Funcs import htmlEncode
import random
try:
    from mx import DateTime
except ImportError:
    import DateTime

True, False = 1==1, 1==0

class NotUsername(Validator.ValidatorConverter):
    def validate(self, value):
        # We'll just imagine three usernames already exist...
        # in real life we'd check a table or something.
        if value in ['bob', 'tim', 'bill']:
            return 'The username <b>%s</b> is already in use.' % value
        else:
            return None

class LovesMother(Validator.ValidatorConverter):
    def validate(self, value):
        if not value:
            return "You don't love your mother?  What kind of person are you?  We don't need that sort of person here."
        else:
            return None

## This is all stuff to set up the form definition.
## Note that I don't do this in the servlet itself.  The
## form definition is seperate from the servlet itself.
favoriteColorList = [((255, 0, 0), 'Red'),
                     ((255, 255, 0), 'Yellow'),
                     ((0, 255, 0), 'Green'),
                     ((0, 0, 255), 'Blue')]

factorList = [("love", "Love"),
              ("money", "Money"),
              ("fame", "Fame")]

fields = [TextField('username', size=10, maxLength=10,
                    validators = [Validator.NotEmpty(),
                                  NotUsername()]),
          PasswordVerifyField('password', validators=[Validator.MinLength(4)]),
          TextField('firstName', size=20, maxLength=40,
                    validators = [Validator.NotEmpty()]),
          TextField('middleInitial', size=2, maxLength=1,
                    description='MI'),
          TextField('lastName', size=30, maxLength=50,
                    validators = [Validator.NotEmpty()]),
          TextField('streetAddress', size=40, maxLength=100),
          CityStateZipField('city'),
          TextField('birthday', size=12, validators=
                    [Validator.DateConverter(),
                     Validator.DateValidator(earliestDate=DateTime.DateTime(1900),
                                             latestDate=DateTime.now()),
                     ]),
          ColorPickerField('favoriteColor', 'ColorPicker'),
          MultiCheckboxField('factors',
                             selections = factorList,
                             listValidators = [Validator.NotEmpty()],
                             description = 'Factors in your registration'),
          SelectField('favoriteNumber',
                      size=4, dynamic=True),
          OrderingField('preference',
                        description='Order by preference',
                        selections=[(x, x) for x in ['Dogs',
                                                     'Cats',
                                                     'Puppies',
                                                     'Children',
                                                     'Cute Frogs']]),
          FileUploadField('webPage',
                          uploadPath='/tmp/',
                          description='Upload your webpage',
                          mimeTypes=['text/html']),
          SubmitButton('submit',
                       description='register'),
          ]

## This should usually use an absolute URL for the action
## ('ComplexRegister'), but we don't know what that will be.  That's
## commonly the case, and it's a bummer.  But this way the
## form can acurately and easily be rendered in a servlet
## other than the one that handles the results.
## For a brief version of a form, consider using options to
## hide some of the fields.
formDef = FormDefinition('ComplexRegister',  # the form action
                         fields, name='form')

def randomNumbers(n=4):
    numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    result = []
    while 1:
        result.append(random.choice(numbers))
        numbers.remove(result[-1])
        if len(result) >= n:
            return result

## We won't actually create random numbers every time...
## That gets weird, because the form will change when they
## resubmit it.  But this shows how we deal with not knowing
## how to fill a form when it is first created.
sessionNumbers = randomNumbers()

class ComplexRegister(ExamplePage, FormServlet):
    def __init__(self):
        FormServlet.__init__(self, [formDef])
        ExamplePage.__init__(self)

    def writeContent(self):
        ## Note, we have to make the RenderableForm to really do
        ## anything with the display.  .htFormTable() formats the form
        ## in an easy table.  RenderableForm has a lot of accessors
        ## for more flexible form creation.
        ## @@ 2001-26-07 ib: random selections don't work so well,
        ## because they change from run to run, so you can't keep
        ## your selection -- but at this stage I can't tell what they
        ## selected to add it to the list.
        print self.request().fields()
        submitted, data = self.processForm()
        if not submitted:
            rf = self.renderableForm(
                optionSet={'favoriteNumber':
                           {'selections': map(lambda x: (x, x), sessionNumbers)}})
            self.write(rf.htFormLayout([
                'username',
                ':password',
                ('firstName', 'middleInitial', 'lastName'),
                'streetAddress',
                ':city',
                ('birthday', 'favoriteColor'),
                ('factors', 'preference'),
                'favoriteNumber',
                'webPage',
                ':submit'], spacing=3))
        else:
            self.write('You logged in with these values:<p>\n')
            self.write('<table border=1>\n')
            for name, value in data.items():
                self.write('<tr><td align=right>%s</td><td>%s</td></tr>\n'
                           % (htmlEncode(name), htmlEncode(str(value))))
            self.write('</table>\n')

