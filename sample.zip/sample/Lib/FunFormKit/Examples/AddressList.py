"""
This is an example to show how to use compound fields
and repeating fields together, to create a repeating
list of fields.
"""

from WebKit.Examples.ExamplePage import ExamplePage
from FunFormKit.Field import *
from FunFormKit.Form import *
from FunFormKit import Validator
from WebUtils.Funcs import htmlEncode

formDef = FormDefinition(
    'AddressList',
    [CompoundField('addresses', [
    TextField('firstName', size=20, maxLength=50),
    TextField('middleInitial', maxLength=1, description='MI'),
    TextField('lastName', size=25, maxLength=50),
    TextareaField('address', rows=2, cols=40),
    CompoundField('phoneNumbers', [
    SelectField('phoneType', selections=[
    ('home', 'Home'), ('work', 'Work'), ('mobile', 'Cell')],
                description='type'),
    TextField('number', validators=[Validator.PhoneNumber(ifEmpty=None)]),
    ], options={'repeat': 3}),
    ], options={'repeat': 10}),
     SubmitButton('save'),
     SubmitButton('clear', methodToInvoke='clearAddresses'),
     ])


class AddressList(ExamplePage, FormServlet):

    def __init__(self):
        FormServlet.__init__(self, [formDef])
        ExamplePage.__init__(self)

    def writeContent(self):
        ses = self.session()
        #ses.delValue('addresses')
        addresses = ses.value('addresses', [])
        submitted, data = self.processForm()
        if submitted:
            self.write('Previous address list:<br>\n')
            self.writeAddresses(addresses)
            self.write('<hr noshade>\n')
            addresses = self.filterAddresses(data['addresses'])
            ses.setValue('addresses', addresses)
        self.writeAddresses(addresses)
        options = {'addresses': {'repeat': len(addresses)+2}}
        defaults = {'addresses': ([None, None] + addresses)}
        rf = self.renderableForm(defaults=defaults,
                                 optionSet=options)
        self.write(rf.htFormLayout([
            ':addresses',
            '=(If you want to add more, save your changes and new blanks will be created)',
            ('save', 'clear')]))

    def filterAddresses(self, addresses):
        new = []
        for address in addresses:
            phone = []
            for p in address['phoneNumbers']:
                if p['number']:
                    phone.append({'phoneType': p['phoneType'],
                                  'number': p['number']})
            address['phoneNumbers'] = phone
            good = 0
            for name in ['firstName', 'lastName']:
                if address[name]:
                    good = 1
            if good:
                new.append(address)
        return new

    def writeAddresses(self, addresses):
        self.write('<table style="border: thin black solid">\n')
        for header in ['Name', 'Address', 'Phone']:
            self.write('<th bgcolor="#bbbbbb">%s</th>\n' % header)
        for a in addresses:
            self.write('<tr>\n')
            self.write('<td>%s %s %s</td>\n'
                       % (htmlEncode(a['firstName']),
                          htmlEncode(a['middleInitial']),
                          htmlEncode(a['lastName'])))
            self.write('<td>%s</td>\n'
                       % newLineEncode(a['address']))
            print 'Address:', a
            self.write('<td>%s</td>\n'
                       % '<br>\n'.join(['%s: %s' % (p['phoneType'], p['number']) for p in a['phoneNumbers']]))
            self.write('</tr>\n')
        self.write('</table>\n')

    def clearAddresses(self, fields):
        if self.session().hasValue('session'):
            self.session().delValue('session')
        return {'addresses': []}

def newLineEncode(val):
    val = htmlEncode(val)
    return val.replace('\n', '<br>\n')
