# -*- coding: utf-8 -*-
# Generated automatically by PSP compiler on Mon May 08 16:47:25 2017

import time
import IssueBook
import datetime
import WebKit
from WebKit import Page
__orig_file__ = 'Context\\IssueBook.psp'

import types
_baseClasses = []
if isinstance(IssueBook.IssueBook, types.ModuleType):
    _baseClasses.append(IssueBook.IssueBook.IssueBook)
else:
    _baseClasses.append(IssueBook.IssueBook)

class Context_IssueBook_psp(_baseClasses[0]):
    def canBeThreaded(self):
        return False
    
    def canBeReused(self):
        return True
    
    def awake(self, trans):
        for baseclass in self.__class__.__bases__:
            if hasattr(baseclass, "awake"):
                baseclass.awake(self, trans)
                break
        self.initPSP()
        
    
    def __includeFile(self, filename):
        self.write(open(filename).read())
    
    def initPSP(self):
        pass
    
    
    def writeHTML(self, transaction=None):
        """I take a WebKit.Transaction object."""
        trans = self._transaction
        res = trans.response()
        req = trans.request()
        self._writeHTML(res, req, trans)
    def _writeHTML(self, res, req=None, trans=None):
        """I take a file-like object. I am useful for unit testing."""
        _formatter = str
        res.write("""


<html>

<head>


<title>Issue Book</title>
  <link rel=\"stylesheet\" href=\"//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css\">
  <link rel=\"stylesheet\" href=\"/resources/demos/style.css\">
  <script src=\"https://code.jquery.com/jquery-1.12.4.js\"></script>
  <script src=\"https://code.jquery.com/ui/1.12.1/jquery-ui.js\"></script>
  <link href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\" rel=\"stylesheet\" integrity=\"sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u\" crossorigin=\"anonymous\">
  <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\" integrity=\"sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa\" crossorigin=\"anonymous\"></script>
  <script>
  $( function() {
    //alert(\"Hello\");
    $( \"#issuedate\" ).datepicker({
    minDate: 0
    });
    $( \"#exptdate\" ).datepicker(
    {minDate: 1});

    // selecte users option
    document.getElementById(\"users\").selectedIndex = """)
        res.write(_formatter(self.get_validation_error().get('field_subsriber_id', "0") ))
        res.write(""";
  } );
 </script>


 <script>
 // search table logic
function searchTable() {
    var input, filter, found, table, tr, td, i, j;
    input = document.getElementById('myinput');
    filter = input.value.toUpperCase();
    table = document.getElementById(\"mytable\");
    tr = table.getElementsByTagName(\"tr\");
    for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName(\"td\");
        for (j = 0; j < td.length; j++) {
            if (td[j].innerHTML.toUpperCase().indexOf(filter) > -1) {
                found = true;
            }
        }
        if (found) {
            tr[i].style.display = \"\";
            found = false;
        } else {
            tr[i].style.display = \"none\";
        }
    }
}
</script>


<nav class=\"navbar navbar-inverse\">
  <div class=\"container-fluid\">
    <div class=\"navbar-header\">
      <a class=\"navbar-brand\" href=\"/Home.psp\">Library Managemengt</a>
    </div>
    <ul class=\"nav navbar-nav\">
      <li><a href=\"/Subscriber.psp\">Add / View Subscriber</a></li>
      <li><a href=\"/Book.psp\">Add / View Books</a></li>
    </ul>
    <ul class=\"nav navbar-nav navbar-right\">
      <li><a href=\"#\"><span class=\"glyphicon glyphicon-user\"></span> Sign Up</a></li>
      <li><a href=\"#\"><span class=\"glyphicon glyphicon-log-in\"></span> Login</a></li>
    </ul>
  </div>
</nav>

<br>

 <b>""")
        res.write(_formatter(time.ctime() ))
        res.write("""</b>
  <br>
  <br>
 <a href=\"/Book.psp\"   style=\"padding-left: 552px;\"> Add Books / View Books</a>
 <h3> Issue Book </h3>
 <br>
</head>


<body style=\"margin-left: 220px;\">

<form action=\"IssueBook?bookid=""")
        res.write(_formatter(req.queryString().split('=')[-1] ))
        res.write("""\" method=\"post\">
<div class=\"form-group\">
    <label for=\"Book_id\">Book Id:</label>
    """)
        res.write(_formatter(req.queryString().split('=')[-1] ))
        res.write("""
</div>
<div class=\"form-group\">
    <label for=\"FromDate\">From Date:</label>
    <input type=\"text\" id=\"issuedate\" name=\"issuedate\" value= \"""")
        res.write(_formatter(self.get_validation_error().get('field_issuedate', "") ))
        res.write("""\" class=\"form-control\" style=\"width: 254px;\">
    <span style=\"color:red\">""")
        res.write(_formatter(self.get_validation_error().get('issuedate', "")  ))
        res.write(""" </span>
</div>
<div class=\"form-group\">
    <label for=\"ExpectedreturnDate\">Expected return Date:</label>
    <input type=\"text\" id=\"exptdate\" name=\"exptdate\" value= \"""")
        res.write(_formatter(self.get_validation_error().get('field_exptdate', "") ))
        res.write("""\" class=\"form-control\" style=\"width: 254px;\">
    <span style=\"color:red\">""")
        res.write(_formatter(self.get_validation_error().get('exptdate', "")  ))
        res.write(""" </span>
</div>
<div class=\"form-group\">
    <label for=\"Subsciber\">Subsciber:</label>
    <select name=\"users\" id=\"users\" style=\"width:160px\" class=\"form-control\" style=\"width:252px;\">
      <option value=\"0\"> Select Subscriber </option>
      """)
        for id, name in self.getSubscribers(): 

            
            res.write("""
         <option value=\"""")
            res.write(_formatter(id  ))
            res.write("""\">""")
            res.write(_formatter(name ))
            res.write("""</option>
      """)
        
        res.write("""
    </select>
    <span style=\"color:red\">""")
        res.write(_formatter(self.get_validation_error().get('subsriber_id', "")  ))
        res.write(""" </span>

</div>
<div class=\"form-group\">
  <input type=\"submit\" value=\"Issue Book\" class=\"btn btn-success btn-sm\" />
  </div>

</form>


<h3 style=\"color:blue;margin-left: 420px;\"> Order List</h3><input id='myinput' onkeyup='searchTable()' type='text' class=\"form-control\" style=\"margin-left: 720px;width:254px;\" placeholder=\"search by keyword\">
<br>
<table  border=\"1\" id=\"mytable\" class=\"table table-striped\" style=\"width:1000px;\">
<th colspan='10%'> OrderID </th>
<th colspan='10%'> Book </th>
<th colspan='10%'> Subscriber </th>
<th colspan='10%'> Issue Date </th>
<th colspan='10%'> Expected Return Date </th>
<th colspan='10%'> Status</th>
""")
        for data in self.get_ordersubscribers(): 

            
            res.write("""

   <tr>
   <td colspan='10%'>""")
            res.write(_formatter(data[0] ))
            res.write("""</td>
   <td colspan='10%'>""")
            res.write(_formatter(data[4]))
            res.write("""</td>
   <td colspan='10%'>""")
            res.write(_formatter(data[5] ))
            res.write("""</td>
   <td colspan='10%'>""")
            res.write(_formatter(data[1].strftime('%d-%b-%Y') ))
            res.write("""</td>
   <td colspan='10%'>""")
            res.write(_formatter(data[2].strftime('%d-%b-%Y') ))
            res.write(""" </td>
   <td colspan='10%'>""")
            res.write(_formatter(data[3] ))
            res.write(""" </td>

   </tr>

""")
        
        res.write("""




</table>












</body>


</html>""")
        
    ##footer
