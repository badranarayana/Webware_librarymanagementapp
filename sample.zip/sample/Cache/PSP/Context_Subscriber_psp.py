# -*- coding: utf-8 -*-
# Generated automatically by PSP compiler on Mon May 08 15:45:05 2017

import time
import Subscriber
import WebKit
from WebKit import Page
__orig_file__ = 'Context\\Subscriber.psp'

import types
_baseClasses = []
if isinstance(Subscriber.Subscriber, types.ModuleType):
    _baseClasses.append(Subscriber.Subscriber.Subscriber)
else:
    _baseClasses.append(Subscriber.Subscriber)

class Context_Subscriber_psp(_baseClasses[0]):
    def canBeThreaded(self):
        return False
    
    def canBeReused(self):
        return True
    
    def awake(self, trans):
        for baseclass in self.__class__.__bases__:
            if hasattr(baseclass, "awake"):
                baseclass.awake(self, trans)
                break
        self.initPSP()
        
    
    def __includeFile(self, filename):
        self.write(open(filename).read())
    
    def initPSP(self):
        pass
    
    
    def writeHTML(self, transaction=None):
        """I take a WebKit.Transaction object."""
        trans = self._transaction
        res = trans.response()
        req = trans.request()
        self._writeHTML(res, req, trans)
    def _writeHTML(self, res, req=None, trans=None):
        """I take a file-like object. I am useful for unit testing."""
        _formatter = str
        res.write("""


<html>
<head>
<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>
 <link rel=\"stylesheet\" href=\"//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css\">
  <link rel=\"stylesheet\" href=\"/resources/demos/style.css\">
  <script src=\"https://code.jquery.com/jquery-1.12.4.js\"></script>
  <script src=\"https://code.jquery.com/ui/1.12.1/jquery-ui.js\"></script>
<link href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\" rel=\"stylesheet\" integrity=\"sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u\" crossorigin=\"anonymous\">
<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\" integrity=\"sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa\" crossorigin=\"anonymous\"></script>

  <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\">
<script>
 // search table logic
function searchTable() {
    var input, filter, found, table, tr, td, i, j;
    input = document.getElementById('myinput');
    filter = input.value.toUpperCase();
    table = document.getElementById(\"mytable\");
    tr = table.getElementsByTagName(\"tr\");
    for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName(\"td\");
        for (j = 0; j < td.length; j++) {
            if (td[j].innerHTML.toUpperCase().indexOf(filter) > -1) {
                found = true;
            }
        }
        if (found) {
            tr[i].style.display = \"\";
            found = false;
        } else {
            tr[i].style.display = \"none\";
        }
    }
}
</script>
<script>

function showPopUpRecords(sub_id){
           alert(sub_id);


}


</script>


<script>
  $( function() {
    //alert(\"Hello\");
    $( \"#returndate\" ).datepicker(
    {minDate: 0,
    maxDate:0});

    // selecte users option
    //document.getElementById(\"users\").selectedIndex = """)
        res.write(_formatter(self.get_validation_error().get('field_subsriber_id', "0") ))
        res.write(""";
  } );

  </script>
<nav class=\"navbar navbar-inverse\">
  <div class=\"container-fluid\">
    <div class=\"navbar-header\">
      <a class=\"navbar-brand\" href=\"/Home.psp\">Library Management</a>
    </div>
    <ul class=\"nav navbar-nav\">
      <li class=\"active\"><a href=\"/Subscriber.psp\">Add / View Subscriber</a></li>
      <li><a href=\"/Book.psp\">Add / View Books</a></li>
    </ul>
    <ul class=\"nav navbar-nav navbar-right\">
      <li><a href=\"#\"><span class=\"glyphicon glyphicon-user\"></span> Sign Up</a></li>
      <li><a href=\"#\"><span class=\"glyphicon glyphicon-log-in\"></span> Login</a></li>
    </ul>
  </div>
</nav>
<b>""")
        res.write(_formatter(time.ctime() ))
        res.write("""</b>
<a href=\"/Book.psp\"  style=\"padding-left: 552px;\"> Add Books / View Books </a>
<br>
<h3> Add Subcriber </h3>
</head>

<body style=\"margin-left: 220px;\">


<form  action=\"Subscriber\" method=\"post\">
<div class=\"form-group\">
    <label for=\"Name\">Name:</label>
    <input type=\"text\" name=\"name\" value= \"""")
        res.write(_formatter(self.get_validation_error().get('field_name', "") ))
        res.write("""\" class=\"form-control\" style=\"width: 254px;\">
    <span style=\"color:red\">""")
        res.write(_formatter(self.get_validation_error().get('name', "")  ))
        res.write(""" </span>
</div>
<div class=\"form-group\">
    <label for=\"MobileNo\">Mobile number:</label>
    <input type=\"text\" name=\"mobileno\" value= \"""")
        res.write(_formatter(self.get_validation_error().get('field_mobileno', "") ))
        res.write("""\" class=\"form-control\" style=\"width: 254px;\">
    <span style=\"color:red\">""")
        res.write(_formatter(self.get_validation_error().get('mobileno', "")  ))
        res.write(""" </span>
</div>
<div class=\"form-group\">
    <label for=\"EmailID\">Email ID:</label>
    <input type=\"text\" name=\"emailid\" value= \"""")
        res.write(_formatter(self.get_validation_error().get('field_emailid', "") ))
        res.write("""\" class=\"form-control\" style=\"width: 254px;\">
    <span style=\"color:red\">""")
        res.write(_formatter(self.get_validation_error().get('emailid', "")  ))
        res.write(""" </span>
</div>
<div class=\"form-group\">
  <input type=\"submit\" value=\"Add Subscriber\" class=\"btn btn-success btn-sm\" />
</div>

</form>







<h3 style=\"color:blue;margin-left: 420px;\"> Subscribers List </h3><input id='myinput' onkeyup='searchTable()' type='text' class=\"form-control\" style=\"margin-left: 720px;width:254px;\" placeholder=\"search by keyword\">
<br>
<table  border=\"1\" id=\"mytable\" class=\"table table-striped\" style=\"width:1000px;\">
<th colspan='10%'> ID </th>
<th colspan='10%'> Name </th>
<th colspan='10%'> Mobile </th>
<th colspan='10%'> Email </th>
<th colspan='20%'> Actions </th>

""")
        for data in self.getSubscribers(): 

            
            res.write("""

   <tr>
   <td colspan='10%'>""")
            res.write(_formatter(data.id ))
            res.write("""</td>
   <td colspan='10%'>""")
            res.write(_formatter(data.name ))
            res.write("""</td>
   <td colspan='10%'>""")
            res.write(_formatter(data.mobile_no ))
            res.write("""</td>
   <td colspan='10%'>""")
            res.write(_formatter(data.email ))
            res.write("""</td>
   <td colspan='10%'><button type=\"button\" class=\"btn btn-info btn-sm\" data-toggle=\"modal\" data-target=\"#myModal_""")
            res.write(_formatter(data.id ))
            res.write("""\">View History</button>
   <button type=\"button\" class=\"btn btn-info btn-sm\" data-toggle=\"modal\" data-target=\"#returnbook_""")
            res.write(_formatter(data.id ))
            res.write("""\">Return Book</button>


  <!-- Modal history -->
  <div class=\"modal fade\" id=\"myModal_""")
            res.write(_formatter(data.id ))
            res.write("""\" role=\"dialog\">
    <div class=\"modal-dialog modal-lg\">
      <div class=\"modal-content\">
        <div class=\"modal-header\">
          <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
          <h4 class=\"modal-title\">Subscriber Order History</h4>
          <!-- <input id='myinput' onkeyup='searchTable()' type='text' class=\"form-control\" style=\"margin-left: 610px;width:254px;\" placeholder=\"search by keyword\"> -->
        </div>
        <div class=\"modal-body\">
          <table  border=\"1\" class=\"table table-striped\">
            <thead>
            <tr>
            <th colspan='10%'> OrderID </th>
            <th colspan='10%'> Subscriber </th>
            <th colspan='10%'> Book </th>
            <th colspan='10%'> Issued Date </th>
            <th colspan='10%'> Expected Return Date </th>
            <th colspan='10%'> Status </th>
            </tr>
            </thead>

            """)
            for data_dict in self.getSubscriberOrders(data.id): 

                
                res.write("""

               <tr>
               <td colspan='10%'>""")
                res.write(_formatter(data_dict[2] ))
                res.write("""</td>
               <td colspan='10%'>""")
                res.write(_formatter(data_dict[0] ))
                res.write("""</td>
                <td colspan='10%'>""")
                res.write(_formatter(data_dict[1] ))
                res.write("""</td>
               <td colspan='10%'>""")
                res.write(_formatter(data_dict[3].strftime('%d-%b-%Y') ))
                res.write("""</td>
               <td colspan='10%'>""")
                res.write(_formatter(data_dict[4].strftime('%d-%b-%Y') ))
                res.write("""</td>
               <td colspan='10%'>""")
                res.write(_formatter(data_dict[5]))
                res.write("""</td>

               </tr>

            """)
            
            res.write("""


           </table>
        </div>
        <div class=\"modal-footer\">
          <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
        </div>
      </div>
    </div>
  </div>


  <div class=\"modal fade\" id=\"returnbook_""")
            res.write(_formatter(data.id ))
            res.write("""\" role=\"dialog\">
    <div class=\"modal-dialog modal-lg\">
      <div class=\"modal-content\">
        <div class=\"modal-header\">
          <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
          <h4 class=\"modal-title\">Return Book</h4>
          <!-- <input id='myinput' onkeyup='searchTable()' type='text' class=\"form-control\" style=\"margin-left: 610px;width:254px;\" placeholder=\"search by keyword\"> -->
        </div>
        <div class=\"modal-body\">

          <form  action=\"ReturnBook\" method=\"post\">
            <div class=\"form-group\">
                <label for=\"Name\">Subscriber ID:</label>
                <input type=\"text\" name=\"subscriber_id\" value= \"""")
            res.write(_formatter(data.id ))
            res.write("""\" class=\"form-control\" style=\"width: 254px;\">
            </div>
            <div class=\"form-group\">
                <label for=\"Subsciber\">Books:</label>
                <select name=\"books\" id=\"books\" style=\"width:160px\" class=\"form-control\" style=\"width:252px;\">
                <option value=\"0\"> Select Book </option>
                """)
            for book_id, book_name  in  self.getBooksbySubscriberId(data.id): 

                
                res.write("""
                 <option value=\"""")
                res.write(_formatter(book_id ))
                res.write("""\"> """)
                res.write(_formatter(book_name ))
                res.write(""" </option>


                """)
            
            res.write("""
                </select>

            </div>
            <div class=\"form-group\">
                <label for=\"returndate\">Return Date:</label>
                <input type=\"text\" id=\"returndate\" name=\"returndate\" value= \"""")
            res.write(_formatter(self.get_validation_error().get('field_returndate', "") ))
            res.write("""\" class=\"form-control\" style=\"width: 254px;\">
                <span style=\"color:red\">""")
            res.write(_formatter(self.get_validation_error().get('returndate', "")  ))
            res.write(""" </span>
            </div>
            <div class=\"form-group\">
              <input type=\"submit\" value=\"Return Book\" class=\"btn btn-success btn-sm\" />
            </div>
            </form>

        </div>
        <div class=\"modal-footer\">
          <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
        </div>
      </div>
    </div>
  </div>

</td>

   </tr>

""")
        
        res.write("""




</table>



</body>




</html>


""")
        
    ##footer
