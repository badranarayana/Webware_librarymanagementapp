# -*- coding: utf-8 -*-
# Generated automatically by PSP compiler on Wed May 03 09:08:53 2017

from sample import sample
import WebKit
from WebKit import Page
__orig_file__ = 'Context\\sample.psp'

import types
_baseClasses = []
if isinstance(sample, types.ModuleType):
    _baseClasses.append(sample.sample)
else:
    _baseClasses.append(sample)

class Context_sample_psp(_baseClasses[0]):
    def canBeThreaded(self):
        return False
    
    def canBeReused(self):
        return True
    
    def awake(self, trans):
        for baseclass in self.__class__.__bases__:
            if hasattr(baseclass, "awake"):
                baseclass.awake(self, trans)
                break
        self.initPSP()
        
    
    def __includeFile(self, filename):
        self.write(open(filename).read())
    
    def initPSP(self):
        pass
    
    
    def writeForm(self, transaction=None):
        """I take a WebKit.Transaction object."""
        trans = self._transaction
        res = trans.response()
        req = trans.request()
        self._writeForm(res, req, trans)
    def _writeForm(self, res, req=None, trans=None):
        """I take a file-like object. I am useful for unit testing."""
        _formatter = str
        res.write("""


""")
        rf = self.rf 

        res.write("""

<html>
<head>
<h1> """)
        self.htTitle() 

        res.write(""" </h1>
</head>
<body align='center'>
<h1> """)
        self.htTitle() 

        res.write(""" </h1>
""")
        self.renderForm() 

        res.write("""
<table>
<tr><td>FirstName: </td><td> </td></tr>
</table>
</body>
</html>
""")
        
    ##footer
