# -*- coding: utf-8 -*-
# Generated automatically by PSP compiler on Mon May 08 14:09:43 2017

import time
import ReturnBook
import WebKit
from WebKit import Page
__orig_file__ = 'Context\\ReturnBook.psp'

import types
_baseClasses = []
if isinstance(ReturnBook.ReturnBook, types.ModuleType):
    _baseClasses.append(ReturnBook.ReturnBook.ReturnBook)
else:
    _baseClasses.append(ReturnBook.ReturnBook)

class Context_ReturnBook_psp(_baseClasses[0]):
    def canBeThreaded(self):
        return False
    
    def canBeReused(self):
        return True
    
    def awake(self, trans):
        for baseclass in self.__class__.__bases__:
            if hasattr(baseclass, "awake"):
                baseclass.awake(self, trans)
                break
        self.initPSP()
        
    
    def __includeFile(self, filename):
        self.write(open(filename).read())
    
    def initPSP(self):
        pass
    
    
    def writeHTML(self, transaction=None):
        """I take a WebKit.Transaction object."""
        trans = self._transaction
        res = trans.response()
        req = trans.request()
        self._writeHTML(res, req, trans)
    def _writeHTML(self, res, req=None, trans=None):
        """I take a file-like object. I am useful for unit testing."""
        _formatter = str
        res.write("""



<html>
<head>
   <title>Return Book</title>
  <link rel=\"stylesheet\" href=\"//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css\">
  <link rel=\"stylesheet\" href=\"/resources/demos/style.css\">
  <script src=\"https://code.jquery.com/jquery-1.12.4.js\"></script>
  <script src=\"https://code.jquery.com/ui/1.12.1/jquery-ui.js\"></script>
  <link href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\" rel=\"stylesheet\" integrity=\"sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u\" crossorigin=\"anonymous\">
  <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\" integrity=\"sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa\" crossorigin=\"anonymous\"></script>
  <script>
  $( function() {
    //alert(\"Hello\");
    $( \"#returndate\" ).datepicker(
    {minDate: 0,
    maxDate:0});

    // selecte users option
    //document.getElementById(\"users\").selectedIndex = """)
        res.write(_formatter(self.get_validation_error().get('field_subsriber_id', "0") ))
        res.write(""";
  } );


  function addOption(){
     var combo = document.getElementById(\"books\");
     alert(\"Hello\");
     """)
        for id, name in self.getBooksbySubscriberId(2): 

            
            res.write("""
        alert(id);
        var option = document.createElement(\"option\");
	    option.text = """)
            res.write(_formatter(name ))
            res.write(""";
	    option.value = """)
            res.write(_formatter(id ))
            res.write("""
		combo.add(option, null);
      """)
        
        res.write("""
}
 </script>



 <nav class=\"navbar navbar-inverse\">
  <div class=\"container-fluid\">
    <div class=\"navbar-header\">
      <a class=\"navbar-brand\" href=\"/Home.psp\">Library Management</a>
    </div>
    <ul class=\"nav navbar-nav\">
      <li class=\"active\"><a href=\"/Subscriber.psp\">Add Subscriber</a></li>
      <li><a href=\"/Book.psp\">Add Books</a></li>
    </ul>
    <ul class=\"nav navbar-nav navbar-right\">
      <li><a href=\"#\"><span class=\"glyphicon glyphicon-user\"></span> Sign Up</a></li>
      <li><a href=\"#\"><span class=\"glyphicon glyphicon-log-in\"></span> Login</a></li>
    </ul>
  </div>
</nav>

 <b> Hello, This is Return book page </b>
</head>


<body style=\"margin-left: 220px;\" onLoad=\"addOption('books')\";>

<form action=\"ReturnBook?bookid=""")
        res.write(_formatter(req.queryString().split('=')[-1] ))
        res.write("""\" method=\"post\">
<div class=\"form-group\">
    <label for=\"Book_id\">Book Id:</label>
    """)
        res.write(_formatter(req.queryString().split('=')[-1] ))
        res.write("""
</div>
<div class=\"form-group\">
    <label for=\"returndate\">Return Date:</label>
    <input type=\"text\" id=\"returndate\" name=\"returndate\" value= \"""")
        res.write(_formatter(self.get_validation_error().get('field_returndate', "") ))
        res.write("""\" class=\"form-control\" style=\"width: 254px;\">
    <span style=\"color:red\">""")
        res.write(_formatter(self.get_validation_error().get('returndate', "")  ))
        res.write(""" </span>
</div>
<div class=\"form-group\">
    <label for=\"Subsciber\">Subsciber:</label>
    <select name=\"users\" id=\"users\" style=\"width:160px\" class=\"form-control\" style=\"width:252px;\">
      <option value=\"0\"> Select Subscriber </option>
      """)
        for id, name in self.getSubscribers(): 

            
            res.write("""
         <option value=\"""")
            res.write(_formatter(id  ))
            res.write("""\">""")
            res.write(_formatter(name ))
            res.write("""</option>
      """)
        
        res.write("""
    </select>
    <span style=\"color:red\">""")
        res.write(_formatter(self.get_validation_error().get('subsriber_id', "")  ))
        res.write(""" </span>

</div>

<div class=\"form-group\">
    <label for=\"Subsciber\">Books:</label>
    <select name=\"books\" id=\"books\" style=\"width:160px\" class=\"form-control\" style=\"width:252px;\">
      <option value=\"0\"> Select Book </option>
    </select>
    <span style=\"color:red\">""")
        res.write(_formatter(self.get_validation_error().get('subsriber_id', "")  ))
        res.write(""" </span>

</div>
<div class=\"form-group\">
    <label for=\"ExpectedreturnDate\">Expected return Date:</label>
    <input type=\"text\" id=\"exptdate\" name=\"exptdate\" value= \"""")
        res.write(_formatter(self.get_validation_error().get('field_exptdate', "") ))
        res.write("""\" class=\"form-control\" style=\"width: 254px;\">
    <span style=\"color:red\">""")
        res.write(_formatter(self.get_validation_error().get('exptdate', "")  ))
        res.write(""" </span>
</div>
<div class=\"form-group\">
  <input type=\"submit\" value=\"Issue Book\" class=\"btn btn-success btn-sm\" />
  </div>

</form>



</body>


</html>
""")
        
    ##footer
