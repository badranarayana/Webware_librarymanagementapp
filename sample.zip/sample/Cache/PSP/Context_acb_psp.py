# -*- coding: utf-8 -*-
# Generated automatically by PSP compiler on Thu May 04 09:24:23 2017

import time
import acb
import WebKit
from WebKit import Page
__orig_file__ = 'Context\\acb.psp'

import types
_baseClasses = []
if isinstance(acb.acb, types.ModuleType):
    _baseClasses.append(acb.acb.acb)
else:
    _baseClasses.append(acb.acb)

class Context_acb_psp(_baseClasses[0]):
    def canBeThreaded(self):
        return False
    
    def canBeReused(self):
        return True
    
    def awake(self, trans):
        for baseclass in self.__class__.__bases__:
            if hasattr(baseclass, "awake"):
                baseclass.awake(self, trans)
                break
        self.initPSP()
        
    
    def __includeFile(self, filename):
        self.write(open(filename).read())
    
    def initPSP(self):
        pass
    
    
    def writeHTML(self, transaction=None):
        """I take a WebKit.Transaction object."""
        trans = self._transaction
        res = trans.response()
        req = trans.request()
        self._writeHTML(res, req, trans)
    def _writeHTML(self, res, req=None, trans=None):
        """I take a file-like object. I am useful for unit testing."""
        _formatter = str
        res.write("""



<b>""")
        res.write(_formatter(time.ctime() ))
        res.write("""</b>


<head>
<h1> Create/view Users</h1>
</head>
""")
        if req.session().value('message', None): 

            
            res.write("""
<b style=\"color:green\">""")
            res.write(_formatter(req.session().value('message') ))
            res.write("""</b>

""")
        
        res.write("""
<body align=\"center\">
<form  action=\"acb\" method=\"post\">
<table align=\"center\">
<tr><td> Name:  </td><td><input type=\"text\" name=\"name\"></td> </tr>
<tr><td> Email:  </td><td><input type=\"text\" name=\"email\"></td> </tr>
<tr><td> password:  </td><td><input type=\"password\" name=\"password\"></td> </tr>
</table>
<input type=\"submit\" value=\"Save\" />
</form>



<b style=\"color:blue\"> Users List </b>
<table align='center' border=\"1\" style=\"background-color:#FFFFE0;\">

<th colspan='10%'> Name </th>
<th colspan='10%'> Email </th>
<th colspan='10%'> Password </th>


""")
        if req.session().value('user_objects', None): 

            
            for user in req.session().value('user_objects'):

                
                res.write("""
   <tr>
   <td colspan='10%'>""")
                res.write(_formatter(user['name'] ))
                res.write("""</td>
   <td colspan='10%'>""")
                res.write(_formatter(user['email'] ))
                res.write("""</td>
   <td colspan='10%'>""")
                res.write(_formatter(user['password'] ))
                res.write("""</td>
   </tr>

""")
            
        
        res.write("""
</table>
</body>


</html>""")
        
    ##footer
