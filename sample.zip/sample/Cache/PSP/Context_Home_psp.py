# -*- coding: utf-8 -*-
# Generated automatically by PSP compiler on Mon May 08 16:35:03 2017

import WebKit
from WebKit import Page
__orig_file__ = 'Context\\Home.psp'

import types
_baseClasses = []
if isinstance(WebKit.Page, types.ModuleType):
    _baseClasses.append(WebKit.Page.Page)
else:
    _baseClasses.append(WebKit.Page)

class Context_Home_psp(_baseClasses[0]):
    def canBeThreaded(self):
        return False
    
    def canBeReused(self):
        return True
    
    def awake(self, trans):
        for baseclass in self.__class__.__bases__:
            if hasattr(baseclass, "awake"):
                baseclass.awake(self, trans)
                break
        self.initPSP()
        
    
    def __includeFile(self, filename):
        self.write(open(filename).read())
    
    def initPSP(self):
        pass
    
    
    def writeHTML(self, transaction=None):
        """I take a WebKit.Transaction object."""
        trans = self._transaction
        res = trans.response()
        req = trans.request()
        self._writeHTML(res, req, trans)
    def _writeHTML(self, res, req=None, trans=None):
        """I take a file-like object. I am useful for unit testing."""
        _formatter = str
        res.write("""<html>
<head>


<link rel=\"stylesheet\" href=\"//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css\">
  <link rel=\"stylesheet\" href=\"/resources/demos/style.css\">
  <script src=\"https://code.jquery.com/jquery-1.12.4.js\"></script>
  <script src=\"https://code.jquery.com/ui/1.12.1/jquery-ui.js\"></script>
  <link href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\" rel=\"stylesheet\" integrity=\"sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u\" crossorigin=\"anonymous\">
  <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\" integrity=\"sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa\" crossorigin=\"anonymous\"></script>
<nav class=\"navbar navbar-inverse\">
  <div class=\"container-fluid\">
    <div class=\"navbar-header\">
      <a class=\"navbar-brand active\"  href=\"/Home.psp\">Library Management</a>
    </div>
    <ul class=\"nav navbar-nav\">
      <li ><a href=\"/Subscriber.psp\">Add / View Subscriber</a></li>
      <li><a href=\"/Book.psp\">Add / View Books</a></li>
    </ul>
    <ul class=\"nav navbar-nav navbar-right\">
      <li><a href=\"#\"><span class=\"glyphicon glyphicon-user\"></span> Sign Up</a></li>
      <li><a href=\"#\"><span class=\"glyphicon glyphicon-log-in\"></span> Login</a></li>
    </ul>
  </div>
</nav>

<br>
</head>

<body>
<div class=\"well well-lg\">This is Home Page</div>
</body>

</html>""")
        
    ##footer
