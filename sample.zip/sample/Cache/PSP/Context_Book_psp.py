# -*- coding: utf-8 -*-
# Generated automatically by PSP compiler on Mon May 08 16:33:39 2017

import time
import Book
import WebKit
from WebKit import Page
__orig_file__ = 'Context\\Book.psp'

import types
_baseClasses = []
if isinstance(Book.Book, types.ModuleType):
    _baseClasses.append(Book.Book.Book)
else:
    _baseClasses.append(Book.Book)

class Context_Book_psp(_baseClasses[0]):
    def canBeThreaded(self):
        return False
    
    def canBeReused(self):
        return True
    
    def awake(self, trans):
        for baseclass in self.__class__.__bases__:
            if hasattr(baseclass, "awake"):
                baseclass.awake(self, trans)
                break
        self.initPSP()
        
    
    def __includeFile(self, filename):
        self.write(open(filename).read())
    
    def initPSP(self):
        pass
    
    
    def writeHTML(self, transaction=None):
        """I take a WebKit.Transaction object."""
        trans = self._transaction
        res = trans.response()
        req = trans.request()
        self._writeHTML(res, req, trans)
    def _writeHTML(self, res, req=None, trans=None):
        """I take a file-like object. I am useful for unit testing."""
        _formatter = str
        res.write("""


<html>
<head>
<link href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\" rel=\"stylesheet\" integrity=\"sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u\" crossorigin=\"anonymous\">
<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\" integrity=\"sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa\" crossorigin=\"anonymous\"></script>

<script>
 // search table logic
function searchTable() {
    var input, filter, found, table, tr, td, i, j;
    input = document.getElementById('myinput');
    filter = input.value.toUpperCase();
    table = document.getElementById(\"mytable\");
    tr = table.getElementsByTagName(\"tr\");
    for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName(\"td\");
        for (j = 0; j < td.length; j++) {
            if (td[j].innerHTML.toUpperCase().indexOf(filter) > -1) {
                found = true;
            }
        }
        if (found) {
            tr[i].style.display = \"\";
            found = false;
        } else {
            tr[i].style.display = \"none\";
        }
    }
}
</script>

<nav class=\"navbar navbar-inverse\">
  <div class=\"container-fluid\">
    <div class=\"navbar-header\">
      <a class=\"navbar-brand\" href=\"/Home.psp\">Library Management</a>
    </div>
    <ul class=\"nav navbar-nav\">
      <li ><a href=\"/Subscriber.psp\">Add / View Subscriber</a></li>
      <li class=\"active\"><a href=\"/Book.psp\">Add / View Books</a></li>
    </ul>
    <ul class=\"nav navbar-nav navbar-right\">
      <li><a href=\"#\"><span class=\"glyphicon glyphicon-user\"></span> Sign Up</a></li>
      <li><a href=\"#\"><span class=\"glyphicon glyphicon-log-in\"></span> Login</a></li>
    </ul>
  </div>
</nav>

<br>
<b align= \"right\">""")
        res.write(_formatter(time.ctime() ))
        res.write("""</b>
<br>
<h3>Add Books </h3>
<a href=\"/Subscriber.psp\"  style=\"padding-left: 552px;\"> Add Subsciber / View Subscriber </a>
</head>

<body style=\"margin-left: 220px;\">
<form  action=\"Book\" method=\"post\">
<div class=\"form-group\">
    <label for=\"name\">Name:</label>
    <input type=\"text\" name=\"name\" value= \"""")
        res.write(_formatter(self.get_validation_error().get('field_name', "") ))
        res.write("""\" class=\"form-control\" style=\"width: 254px;\">
    <span style=\"color:red\">""")
        res.write(_formatter(self.get_validation_error().get('name', "")  ))
        res.write(""" </span>
  </div>
  <div class=\"form-group\">
    <label for=\"Author_Name\">Author Name::</label>
    <input type=\"text\" name=\"author_name\" value= \"""")
        res.write(_formatter(self.get_validation_error().get('field_author_name', "") ))
        res.write("""\" class=\"form-control\" style=\"width: 254px;\">
    <span style=\"color:red\">""")
        res.write(_formatter(self.get_validation_error().get('author_name', "")  ))
        res.write(""" </span>
  </div>
  <div class=\"form-group\">
    <label for=\"Quantity\">Quantity:</label>
    <input type=\"text\" name=\"quantity\" value= \"""")
        res.write(_formatter(self.get_validation_error().get('field_quantity', "") ))
        res.write("""\" class=\"form-control\" style=\"width: 254px;\">
    <span style=\"color:red\">""")
        res.write(_formatter(self.get_validation_error().get('quantity', "")  ))
        res.write(""" </span>
  </div>
  <div class=\"form-group\">
  <input type=\"submit\" value=\"Add Book\" class=\"btn btn-success btn-sm\"/>
  </div>

</form>


<h3 style=\"color:blue;margin-left: 420px;\"> Books List</h3> <input id='myinput' onkeyup='searchTable()' type='text' class=\"form-control\" style=\"margin-left: 720px;width:254px;\" placeholder=\"search by keyword\">
<br>
<table  border=\"1\" id=\"mytable\" class=\"table table-striped\" style=\"width:1000px;\">
<th colspan='10%'> ID </th>
<th colspan='10%'> Name </th>
<th colspan='10%'> Author </th>
<th colspan='10%'> qty </th>
<th colspan='10%'> Actions </th>
""")
        for data in self.getBooks(): 

            
            res.write("""

   <tr>
   <td colspan='10%'>""")
            res.write(_formatter(data.id ))
            res.write("""</td>
   <td colspan='10%'>""")
            res.write(_formatter(data.name ))
            res.write("""</td>
   <td colspan='10%'>""")
            res.write(_formatter(data.author_name ))
            res.write("""</td>
   <td colspan='10%'>""")
            res.write(_formatter(data.quantity ))
            res.write("""</td>
   <td colspan='10%' align='center'>
   """)
            if data.quantity > 0 :

                
                res.write("""

    <a href=\"/IssueBook.psp?bookid=""")
                res.write(_formatter(data.id ))
                res.write("""\"  class=\"btn btn-info btn-sm\">Issue Book</a> &nbsp;&nbsp;&nbsp;
   """)
            
            if data.quantity == 0 :

                
                res.write("""
   <a href=\"#\" tooltip=\"out of stock\" class=\"btn btn-warning btn-sm\"> Issue Book </a>&nbsp;&nbsp;&nbsp;
   """)
            
            res.write("""
   </td>

   </tr>

""")
        
        res.write("""




</table>
</body>




</html>


""")
        
    ##footer
