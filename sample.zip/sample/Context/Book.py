from WebKit.Page import Page
from Lib.dbobjects.models import Book as book_table
from Lib.dbobjects.models import insertRecord, create_tables, getSession


class Book(Page):
    """

    """
    # this dict will populate FOrm validation errors
    validation_errors = {}
    def __init__(self):
        Page.__init__(self)
        #self.validation_errors = {}

    def writeContent(self):
        """
        This method takes care about request and response process
        :return: Response tp client
        """
        #self.validation_errors = {}
        req = self.request()
        fields_dict = req.fields()
        name = fields_dict.get('name')
        author_name = fields_dict.get('author_name')
        quantity = fields_dict.get('quantity')

        validation_dict = {}
        # validate name
        if not name:
            print "'NNNNN"
            validation_dict['name'] = "Please Enter Book Name"
        else:
            validation_dict['field_name'] = name

        # validate author name
        if not author_name:
            validation_dict['author_name'] = "Please Enter Author Name"
        else:
            validation_dict['field_author_name'] = name

        # validate quantity
        if not quantity:
            validation_dict['quantity'] = "Please Enter quantity"
        else:
            validation_dict['field_quantity'] = name

        if name and author_name and quantity:
            #create_tables()
            book_object = book_table(name=name, author_name=author_name, quantity=quantity)
            insertRecord(book_object)
            Book.validation_errors = {}
        else:
            Book.validation_errors = validation_dict

        print "######", req.uriWebKitRoot()
        print "servletURI", req.servletURI()


            # do database actions here{'name': name, 'email': email, 'password': password})

        # print "Response", dir(self.response())
        return self.response().sendRedirectPermanent(req.serverURL() + ".psp")

    def getBooks(self):
        return getSession().query(book_table)

    def get_validation_error(self):
        return Book.validation_errors
