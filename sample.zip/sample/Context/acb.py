from Lib.FunFormKit import Form
from Lib.FunFormKit.Form import FormServlet
from Lib.FunFormKit import Field
from Lib.FunFormKit import Validator
from WebKit.Page import Page


formDef = Form.FormDefinition(
    "sample.psp",
    [Field.TextField("firstName", maxLength=20, validators=[Validator.NotEmpty()]),
     Field.TextField("middleInitial", description="MI",
               size=1, maxLength=1),
     Field.TextField("lastName", maxLength=50, size=20, validators=[Validator.NotEmpty()]),
     Field.SubmitButton("submit", methodToInvoke="register"),
     ])

layout = [("firstName*"),( "middleInitial"), ("lastName*"),
          "submit",
          ]


class acb(Page):
    """

    """

    def __init__(self):
        Page.__init__(self)
        #FormServlet.__init__(self, formDef)

    def writeContent(self):
        print "Requested the page"
        req = self.request()
        if req.method == 'post':
            print "Post request"
        if self.session().value('user_objects', None):
            print "Session data", self.session().value('user_object', None)

        fields_dict = req.fields()
        name = fields_dict.get('name')
        email = fields_dict.get('email')
        password = fields_dict.get('password')
        print "Name:", name
        print "EMail", email
        print "Password", password
        print "Server Path", req.serverURL()
        # do database actions here
        if not req.session().value('user_objects', None):
            print "SESSION not there"
            req.session().setValue("user_objects", [])
            req.session().setValue('message', " ")

        users_list = self.session().value('user_objects', None)
        users_list.append({'name': name, 'email': email, 'password': password})
        req.session().setValue('user_objects', users_list)
        req.session().setValue('message', "User Added Successfully")
        #print "Response", dir(self.response())
        return self.response().sendRedirectPermanent(req.serverURL() + ".psp")

    # def renderForm(self):
    #     renderableForm = self.renderableForm()
    #     return renderableForm.htFormLayout(layout)
    def sayhai(self):
        return "HO, how are you"


def ptintHai():
    return "Hi, How are you"
