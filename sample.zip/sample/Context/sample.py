#from WebKit.Page import Page
from funforms.sample import Register1
class sample(Register1):
    def hello(self):
        #print dir(Register)
        #print dir(self)
        pass

    def title(self):
        """The page title.

        Subclasses often override this method to provide a custom title.
        This title should be absent of HTML tags. This implementation
        returns the name of the class, which is sometimes appropriate
        and at least informative.
        """
        return "This is custom title"

    def htTitle(self):
        """The page title as HTML.

        Return self.title(). Subclasses sometimes override this to provide
        an HTML enhanced version of the title. This is the method that should
        be used when including the page title in the actual page contents.
        """
        return self.title()

    def writeHead(self):
        """Write the <head> element of the page.

        Writes the ``<head>`` portion of the page by writing the
        ``<head>...</head>`` tags and invoking `writeHeadParts` in between.
        """
        wr = self.writeln
        wr('<head>')
        wr('<h1> This is Home Page </h1>')
        self.writeHeadParts()
        wr('</head>')

    def writeHeadParts(self):
        """Write the parts included in the <head> element.

        Writes the parts inside the ``<head>...</head>`` tags.
        Invokes `writeTitle` and then `writeMetaData`, `writeStyleSheet`
        and `writeJavaScript`. Subclasses should override the `title`
        method and the three latter methods only.
        """
        self.writeTitle()
        #self.writeMetaData()
        #self.writeStyleSheet()
        #self.writeJavaScript()

    def writeTitle(self):
        """Write the <title> element of the page.

        Writes the ``<title>`` portion of the page.
        Uses `title`, which is where you should override.
        """
        self.writeln('\t<title>%s</title>' % self.title())

    def htBodyArgs(self):
        """The attributes for the <body> element.

        Returns the arguments used for the HTML <body> tag.
        Invoked by writeBody().

        With the prevalence of stylesheets (CSS), you can probably skip
        this particular HTML feature, but for historical reasons this sets
        the page to black text on white.
        """
        return 'style="color:black;background-color:volite;padding: 200px;'

    def writeBody(self):
        """Write the <body> element of the page.

        Writes the ``<body>`` portion of the page by writing the
        ``<body>...</body>`` (making use of `htBodyArgs`) and
        invoking `writeBodyParts` in between.
        """
        wr = self.writeln
        bodyArgs = self.htBodyArgs()
        if bodyArgs:
            wr('<body %s>' % bodyArgs)
        else:
            wr('<body>')
        self.writeBodyParts()
        wr('<%= range(10) %> ')

        wr('</body>')

    def writeBodyParts(self):
        """Write the parts included in the <body> element.

        Invokes `writeContent`. Subclasses should only override this method
        to provide additional page parts such as a header, sidebar and footer,
        that a subclass doesn't normally have to worry about writing.

        For writing page-specific content, subclasses should override
        `writeContent`() instead. This method is intended to be overridden
        by your SitePage.

        See `SidebarPage` for an example override of this method.

        Invoked by `writeBody`.
        """
        self.writeContent()

    # def writeContent(self):
    #     """Write the unique, central content for the page.
    #
    #     Subclasses should override this method (not invoking super) to write
    #     their unique page content.
    #
    #     Invoked by `writeBodyParts`.
    #     """
    #     self.writeln('<p> This page has not yet customized its content. </p>')


