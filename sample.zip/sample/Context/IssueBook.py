
from WebKit.Page import Page
from Lib.dbobjects.models import Subscriber as subscriber_table
from Lib.dbobjects.models import Book as book_table
from Lib.dbobjects.models import Subscriptions
from Lib.dbobjects.models import insertRecord, create_tables, getSession
from  datetime import datetime, timedelta




class IssueBook(Page):
    """

    """
    validation_errors = {}

    def __init__(self):
        Page.__init__(self)

    def writeContent(self):
        error_flag = False
        print "Requested the page"
        #create_tables()
        req = self.request()
        #print "%%%%%%%", req.queryString().split('=')[-1]
        fields_dict = req.fields()

        bood_id = fields_dict.get('bookid')
        subsriber_id = fields_dict.get('users')
        issue_from = fields_dict.get('issuedate')
        expected_return = fields_dict.get('exptdate')

        validation_dict = {}
        # validate author name
        if not subsriber_id or subsriber_id == '0':
            validation_dict['subsriber_id'] = "Please select subscriber"
            error_flag = True
        else:
            validation_dict['field_subsriber_id'] = subsriber_id

        # validate quantity
        if not issue_from:
            validation_dict['issuedate'] = "Please pick issue date"
        else:
            validation_dict['field_issuedate'] = issue_from

        if not expected_return:
            validation_dict['exptdate'] = "Please pick expected return date"
        else:
            validation_dict['field_exptdate'] = expected_return

        if issue_from and expected_return:
            if issue_from > expected_return:
                validation_dict['exptdate'] = "Please pick date greater than issue date"
                error_flag = True




        #IssueBook.validation_errors = validation_dict
        # converting string date into date object
        #datetime.strptime('05/03/2017', "%m/%d/%Y").date()
        # print "----->",fields_dict
        # #issue_time = datetime.now()
        # #expected_datetime = issue_time + timedelta(weeks=5)

        if bood_id and subsriber_id and issue_from and expected_return and not error_flag:

            subscips_object = Subscriptions(book_id=bood_id,
                                            subsriber_id=subsriber_id,
                                            issue_from=datetime.strptime(issue_from, "%m/%d/%Y").date(),
                                            expected_return=datetime.strptime(expected_return, "%m/%d/%Y").date())
            insertRecord(subscips_object)

            session = getSession()
            # update books count after issuing the book
            book_object = session.query(book_table).filter(book_table.id == bood_id).one()
            book_object.quantity = book_object.quantity - 1
            session.add(book_object)
            session.commit()

            IssueBook.validation_errors = {}
        else:
            IssueBook.validation_errors = validation_dict
        # for i in self.get_ordersubscribers():
        #     print i.book_id, i.issue_from


        # print "Response", dir(self.response())
        return self.response().sendRedirectPermanent(req.serverURL() + ".psp?bookid=" + bood_id)

    def getSubscribers(self):
        return getSession().query(subscriber_table.id, subscriber_table.name)

    def get_ordersubscribers(self):
        return getSession().query(Subscriptions.id, Subscriptions.issue_from, Subscriptions.expected_return, Subscriptions.status,
                                  book_table.name, subscriber_table.name).join(book_table, book_table.id == Subscriptions.book_id).\
            join(subscriber_table, Subscriptions.subsriber_id == subscriber_table.id)

    def getBooks(self):
        return getSession().query(book_table.id, book_table.name)

    def get_validation_error(self):
        return IssueBook.validation_errors