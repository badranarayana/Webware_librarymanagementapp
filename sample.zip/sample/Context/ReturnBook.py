from WebKit.Page import Page
from Lib.dbobjects.models import Subscriber as subscriber_table
from Lib.dbobjects.models import Book as book_table
from Lib.dbobjects.models import Subscriptions as subscris_table
from Lib.dbobjects.models import insertRecord, create_tables, getSession
from  datetime import datetime, timedelta




class ReturnBook(Page):
    """
    This class is to handling  the book returning functionality
    """

    def __init__(self):
        Page.__init__(self)

    def writeContent(self):
        print "Requested the page"
        # create_tables()
        req = self.request()
        fields_dict = req.fields()
        subscriber_id = fields_dict.get('subscriber_id')
        book_id = fields_dict.get('books')
        return_date = fields_dict.get('returndate')

        if book_id and subscriber_id and return_date:
            session = getSession()

            book_object = session.query(subscris_table).filter(subscris_table.subsriber_id == subscriber_id).filter(subscris_table.book_id == book_id).one()

            book_object.status = "Recieved"

            book_object.expected_return = datetime.strptime(return_date, "%m/%d/%Y").date()
            session.add(book_object)
            session.commit()

            #update book count
            session = getSession()
            book_object = session.query(book_table).filter(book_table.id == book_id).one()
            book_object.quantity = book_object.quantity + 1
            session.add(book_object)
            session.commit()

        return self.response().sendRedirectPermanent("/Subscriber" + ".psp")

    def get_validation_error(self):
        return {}

    def getSubscribers(self):
        return getSession().query(subscriber_table.id, subscriber_table.name)

    def getBooksbySubscriberId(self, subscriber_id):
        return getSession().query(book_table.id, book_table.name)\
            .join(subscris_table, book_table.id == subscris_table.book_id).filter(subscris_table.subsriber_id == subscriber_id)
