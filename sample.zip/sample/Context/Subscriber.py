from WebKit.Page import Page
from Lib.dbobjects.models import Subscriber as subscriber_table
from Lib.dbobjects.models import Book as book_table
from Lib.dbobjects.models import Subscriptions as subscris_table
from Lib.dbobjects.models import insertRecord, create_tables, getSession

class Subscriber(Page):
    """
    
    """
    # this dict populate Form validation errors
    validation_errors = {}
    def __init__(self):
        Page.__init__(self)

    def writeContent(self):

        req = self.request()
        fields_dict = req.fields()
        name = fields_dict.get('name')
        mobileno = fields_dict.get('mobileno')
        emailid = fields_dict.get('emailid')

        validation_dict = {}
        # validate name
        if not name:
            validation_dict['name'] = "Please Enter Subscriber Name"
        else:
            validation_dict['field_name'] = name

        # validate author name
        if not mobileno:
            validation_dict['mobileno'] = "Please Enter Mobile Number"
        else:
            validation_dict['field_mobileno'] = mobileno

        # validate quantity
        if not emailid:
            validation_dict['emailid'] = "Please Enter Email"
        else:
            validation_dict['field_emailid'] = emailid

        if name and mobileno and emailid:
            #create_tables()

            subscriber_object = subscriber_table(name=name, mobile_no=mobileno, email=emailid)
            insertRecord(subscriber_object)
            Subscriber.validation_errors = {}

        else:
            Subscriber.validation_errors = validation_dict

        data_dict = self.getSubscriberOrders(9)
        for i in data_dict:
            print "$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$", i

        # Redirecting request
        return self.response().sendRedirectPermanent(req.serverURL() + ".psp")

    def getSubscribers(self):
        return getSession().query(subscriber_table)

    def get_validation_error(self):
        return Subscriber.validation_errors

    def getSubscriberOrders(self, Subscriber_id):

        q = getSession().query(subscriber_table.name, book_table.name, subscris_table.id,  subscris_table.issue_from, subscris_table.expected_return, subscris_table.status).join(subscris_table, subscris_table.subsriber_id == subscriber_table.id)\
            .join(book_table, subscris_table.book_id == book_table.id).filter(subscris_table.subsriber_id == Subscriber_id)
        return q

    def getBooksbySubscriberId(self, subscriber_id):
        return getSession().query(book_table.id, book_table.name)\
            .join(subscris_table, book_table.id == subscris_table.book_id).filter(subscris_table.subsriber_id == subscriber_id).filter(subscris_table.status == "Issued")
