from Lib.FunFormKit import Form
from Lib.FunFormKit.Form import FormServlet
from Lib.FunFormKit import Field
from Lib.FunFormKit import Validator
from WebKit.Page import Page


formDef = Form.FormDefinition(
    "sample.psp",
    [Field.TextField("firstName", maxLength=20, validators=[Validator.NotEmpty()]),
     Field.TextField("middleInitial", description="MI",
               size=1, maxLength=1),
     Field.TextField("lastName", maxLength=50, size=20, validators=[Validator.NotEmpty()]),
     Field.SubmitButton("submit", methodToInvoke="register"),
     ])

layout = [("firstName*"),( "middleInitial"), ("lastName*"),
          "submit",
          ]


class Register1(Page, FormServlet):
    def __init__(self):
        Page.__init__(self)
        FormServlet.__init__(self, formDef)

    def writeContent(self):
        # .processForm() is inherited from FormServlet
        formProcessed, data = self.processForm()
        if formProcessed:
            self.write('Thanks for signing up!')
        else:
            self.renderForm()

    def renderForm(self):
        renderableForm = self.renderableForm()
        return self.write(renderableForm.htFormLayout(layout))

    def register(self, fields):
        # ... do something to register user in database here ...
        # fields is a dictionary, filled from the form, field
        # names as keys.
        print "form submited"
        self.session().setValue('userInfo', fields)


class Acb(FormServlet):
    """
    
    """
    def __init__(self):
        FormServlet.__init__(self, formDef)


    def writeContent(self):
        # .processForm() is inherited from FormServlet
        formProcessed, data = self.processForm()
        if formProcessed:
            print "DATA :- ", data
        else:
            self.renderForm()
    def renderForm(self):
        renderableForm = self.renderableForm()
        return renderableForm.fields()








